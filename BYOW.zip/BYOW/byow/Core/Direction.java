package byow.Core;

enum Direction {
    UP, DOWN, LEFT, RIGHT;
}
