package byow.Core;

import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import java.io.File;

/**
 * This function to output the music, and we have two arguments to control whether we
 * should play the music or not
 */
public class musicStuff {
    private File musicPath;
    private AudioInputStream audioInput;
    private Clip clip;

    public void playMusic(String musicLocation, boolean musicLoop) {
        try {
            musicPath = new File(musicLocation);

            if (musicPath.exists()) {
                audioInput = AudioSystem.getAudioInputStream(musicPath);
                clip = AudioSystem.getClip();
                clip.open(audioInput);
                clip.start();
                if (musicLoop) {
                    clip.loop(Clip.LOOP_CONTINUOUSLY);
                }
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
    }

    public void stopMusic() {
        clip.stop();
    }
}
