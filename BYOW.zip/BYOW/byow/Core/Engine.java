package byow.Core;

import byow.TileEngine.TERenderer;
import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;
import edu.princeton.cs.algs4.StdDraw;

import java.awt.*;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Stack;

public class Engine {
    TERenderer ter = new TERenderer();
    /* Feel free to change the width and height. */
    public static final int WIDTH = 91;
    public static final int HEIGHT = 41;
    private static boolean viewOn = false;

    /**
     * Method used for exploring a fresh world. This method should handle all inputs,
     * including inputs from the main menu.
     */
    public void interactWithKeyboard() {
        drawStartUI();
        char firstChar = getFirstChar();
        if (firstChar == 'n') {
            newGame();
        } else if (firstChar == 'l') {
            loadGame();
        } else if (firstChar == 'q') {
            System.exit(0);
        } else if (firstChar == 'o') {
            options();
        } else if (firstChar == 'i') {
            instruction();
        }
    }

    /** Game Instruction */
    private void instruction() {
        StdDraw.clear(Color.BLACK);
        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 30));
        StdDraw.text(WIDTH / 2, HEIGHT - 3, "This is the game for doing nothing but exploring the random world");
        StdDraw.text(WIDTH / 2.34, HEIGHT / 2.2, "1. By pressing (V) can turn on/off the viewOn.");
        StdDraw.text(WIDTH / 2, HEIGHT / 3, "2. By pressing (M) can turn on/off the background sounds.");

        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 18));
        StdDraw.text(WIDTH / 2, HEIGHT / 8, "(B) return to Menu");

        StdDraw.show();

        char c;
        while (StdDraw.hasNextKeyTyped()) {
            StdDraw.nextKeyTyped();
        }
        while (true) {
            if (!StdDraw.hasNextKeyTyped()) {
                continue;
            }
            c = Character.toLowerCase(StdDraw.nextKeyTyped());
            if (c == 'b') {
                break;
            }
        }
        if (c == 'b') {
            interactWithKeyboard();
        }
    }

    /**
     * Function to change avatar in Menu
     */
    private void options() {
        StdDraw.clear(Color.BLACK);
        // Options of appearances
        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 80));
        StdDraw.text(WIDTH / 4, 2 * HEIGHT / 4, "@"); // 1st choice
        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 30));
        StdDraw.text(WIDTH / 4, 1.5 * HEIGHT / 4, "1"); //description

        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 80));
        StdDraw.text(2 * WIDTH / 4, 2 * HEIGHT / 4, "大"); // 2nd choice
        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 30));
        StdDraw.text(2 * WIDTH / 4, 1.5 * HEIGHT / 4, "2"); //description

        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 80));
        StdDraw.text(3 * WIDTH / 4, 2 * HEIGHT / 4, "人"); // 3rd choice
        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 30));
        StdDraw.text(3 * WIDTH / 4, 1.5 * HEIGHT / 4, "3"); //description
        // Option back to Menu
        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 18));
        StdDraw.text(WIDTH / 2, HEIGHT / 8, "(B) return to Menu");
        // Option to ask for changing avatar appearance
        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 30));
        StdDraw.text(WIDTH / 2, HEIGHT / 4, "Please choose your new avatar appearance:");
        StdDraw.show();

        char c;
        while (StdDraw.hasNextKeyTyped()) {
            StdDraw.nextKeyTyped();
        }
        while (true) {
            if (!StdDraw.hasNextKeyTyped()) {
                continue;
            }
            c = Character.toLowerCase(StdDraw.nextKeyTyped());
            if (c == '1' || c == '2' || c == '3' || c == 'b') {
                break;
            }
        }
        if (c == '1') {
            Player.changeAppearanceChoice(1);
            interactWithKeyboard();
        } else if (c == '2') {
            Player.changeAppearanceChoice(2);
            interactWithKeyboard();
        } else if (c == '3') {
            Player.changeAppearanceChoice(3);
            interactWithKeyboard();
        } else if (c == 'b') {
            interactWithKeyboard();
        }
        System.out.println(c);
    }

    private void newGame() {
        long seed = getSeed();
        ter.initialize(WIDTH, HEIGHT + 5);
        TETile[][] world = generateWorld(seed);
        ter.renderFrame(world);
        play(world);
    }

    private long getSeed() {
        StdDraw.clear(Color.BLACK);
        StdDraw.setFont(new Font("Monaco", Font.PLAIN, 50));
        StdDraw.text(WIDTH / 2, 3 * HEIGHT / 4, "Please enter a random seed:");

        Font smallerFont = new Font("Monaco", Font.PLAIN, 18);
        StdDraw.setFont(smallerFont);
        StdDraw.text(1.8 * WIDTH / 2, HEIGHT, "(V) Turn On/Off ViewOn");

        StdDraw.show();
        String seedString = "";
        while (true) {
            StdDraw.clear(Color.BLACK);
            StdDraw.setFont(new Font("Monaco", Font.PLAIN, 50));
            StdDraw.text(WIDTH / 2, 3 * HEIGHT / 4, "Please enter a random seed:");

            StdDraw.setFont(smallerFont);
            StdDraw.text(1.8 * WIDTH / 2, HEIGHT, "(V) Turn On/Off ViewOn");

            char digit;
            if (!StdDraw.hasNextKeyTyped()) {
                continue;
            }
            digit = Character.toLowerCase(StdDraw.nextKeyTyped());
            if (digit != 's') {
                if (!Character.isDigit(digit)) {
                    continue;
                }
                seedString += digit;
                StdDraw.setFont(new Font("Monaco", Font.PLAIN, 30));
                StdDraw.text(WIDTH / 2, HEIGHT / 2, seedString);
                StdDraw.show();
            } else {
                break;
            }
        }
        long seed = convertSeed(seedString);
        return seed;
    }

    /**
     * Get every input from the Keyboard
     */
    private char getFirstChar() {
        char c;
        while (true) {
            if (!StdDraw.hasNextKeyTyped()) {
                continue;
            }
            c = Character.toLowerCase(StdDraw.nextKeyTyped());
            if (c == 'n' || c == 'l' || c == 'q' || c == 'o' || c == 'i') {
                break;
            }
        }
        return c;
    }

    /**
     * Method used for autograding and testing your code. The input string will be a series
     * of characters (for example, "n123sswwdasdassadwas", "n123sss:q", "lwww". The engine should
     * behave exactly as if the user typed these characters into the engine using
     * interactWithKeyboard.
     * <p>
     * Recall that strings ending in ":q" should cause the game to quite save. For example,
     * if we do interactWithInputString("n123sss:q"), we expect the game to run the first
     * 7 commands (n123sss) and then quit and save. If we then do
     * interactWithInputString("l"), we should be back in the exact same state.
     * <p>
     * In other words, running both of these:
     * - interactWithInputString("n123sss:q")
     * - interactWithInputString("lww")
     * <p>
     * should yield the exact same world state as:
     * - interactWithInputString("n123sssww")
     *
     * @param input the input string to feed to your program
     * @return the 2D TETile[][] representing the state of the world
     */
    public TETile[][] interactWithInputString(String input) {
        input = input.toLowerCase();
        TETile[][] finalWorldFrame = null;
        char firstChar = input.charAt(0);
        if (firstChar == 'n') {
            finalWorldFrame = newGame(input);
        } else if (firstChar == 'l') {
            finalWorldFrame = loadGame(input);
        } else if (firstChar == 'q') {
            System.exit(0);
        } else if (firstChar == 'o') {
            options();
        } else if (firstChar == 'i') {
            instruction();
        }
        return finalWorldFrame;
    }

    private TETile[][] newGame(String input) {
        TETile[][] finalWorldFrame;
        int indexS = input.indexOf('s');
        long seed = convertSeed(input.substring(1, indexS));
        finalWorldFrame = generateWorld(seed);

        play(finalWorldFrame, input.substring(indexS + 1));
        return finalWorldFrame;
    }

    private TETile[][] loadGame(String input) {
        TETile[][] finalWorldFrame;
        finalWorldFrame = getSavedGame();
        play(finalWorldFrame, input.substring(1));
        return finalWorldFrame;
    }

    private void loadGame() {
        ter.initialize(WIDTH, HEIGHT + 1);
        TETile[][] world = getSavedGame();
        ter.renderFrame(world);
        play(world);
    }

    private void play(TETile[][] world, String playString) {
        for (int i = 0; i < playString.length(); i++) {
            switch (playString.charAt(i)) {
                case 'm':
                    String filePath = "tile_effect.wav";
                    musicStuff musicObject = new musicStuff();
                    musicObject.playMusic(filePath, false);
                    break;
                case 'w':
                    Player.walkUp(world);
                    break;
                case 'a':
                    Player.walkLeft(world);
                    break;
                case 's':
                    Player.walkDown(world);
                    break;
                case 'd':
                    Player.walkRight(world);
                    break;
                case ':':
                    if (i + 1 < playString.length() && playString.charAt(i + 1) == 'q') {
                        saveGame(world);
                        return;
                    }
                    break;
                default:
            }
        }
    }

    /**
     * Function to control the Avatar to move
     */
    private void play(TETile[][] world) {
        TETile[][] view;
        // Sound effect
        String filePath = "tile_effect.wav";
        musicStuff musicObject = new musicStuff();
        boolean musicOn = true;
        
        // These code to play bmg during the game
//        String bgmPath = "bgm.wav";
//        musicStuff bgmObject = new musicStuff();
//        bgmObject.playMusic(bgmPath, true);

        // Showing description
        int x;
        int y;
        String tileDescription;
        String tempDescription = null;
        while (true) {
            x = (int) Math.floor(StdDraw.mouseX());
            y = (int) Math.floor(StdDraw.mouseY());
            if (y < 41) {
                tileDescription = world[x][y].description();
            } else {
                tileDescription = Tileset.NOTHING.description();
            }
            if (!tileDescription.equals(tempDescription)) {
                ter.renderFrame(world);
                Font font = new Font("Monaco", Font.BOLD, 14);
                StdDraw.setFont(font);
                StdDraw.text(10, 42, tileDescription);
                StdDraw.show();
                tempDescription = tileDescription;
            }
            if (!StdDraw.hasNextKeyTyped()) {
                continue;
            }
            // Get the char
            char c = Character.toLowerCase(StdDraw.nextKeyTyped());
            switch (c) {
                case 'm':
                    musicOn = !musicOn;
//                    if (musicOn) {
//                        bgmObject.playMusic(bgmPath, true);
//                    } else {
//                        bgmObject.stopMusic();
//                    }
                    break;
                case 'w':
                    Player.walkUp(world);
                    if (musicOn) {
                        musicObject.playMusic(filePath, false);
                    }
                    if (viewOn) {
                        view = generateView(world);
                        ter.renderFrame(view);
                    } else {
                        ter.renderFrame(world);
                    }
                    break;
                case 'a':
                    Player.walkLeft(world);
                    if (musicOn) {
                        musicObject.playMusic(filePath, false);
                    }
                    if (viewOn) {
                        view = generateView(world);
                        ter.renderFrame(view);
                    } else {
                        ter.renderFrame(world);
                    }
                    break;
                case 's':
                    Player.walkDown(world);
                    if (musicOn) {
                        musicObject.playMusic(filePath, false);
                    }
                    if (viewOn) {
                        view = generateView(world);
                        ter.renderFrame(view);
                    } else {
                        ter.renderFrame(world);
                    }
                    break;
                case 'd':
                    Player.walkRight(world);
                    if (musicOn) {
                        musicObject.playMusic(filePath, false);
                    }
                    if (viewOn) {
                        view = generateView(world);
                        ter.renderFrame(view);
                    } else {
                        ter.renderFrame(world);
                    }
                    break;
                case 'v':
                    viewOn = !viewOn;
                    if (viewOn) {
                        view = generateView(world);
                        ter.renderFrame(view);
                    } else {
                        ter.renderFrame(world);
                    }
                    break;
                case ':':
                    while (true) {
                        if (!StdDraw.hasNextKeyTyped()) {
                            continue;
                        }
                        if (Character.toLowerCase(StdDraw.nextKeyTyped()) == 'q') {
                            saveGame(world);
                            System.exit(0);
                        } else {
                            break;
                        }
                    }
                    break;
                default:
            }
        }
    }

    private TETile[][] generateView(TETile[][] world) {
        TETile[][] view = new TETile[WIDTH][HEIGHT];
        int leftX, leftY, rightX, rightY;
        if (Player.getPos().getX() < 2) {
            leftX = 0;
        } else {
            leftX = Player.getPos().getX() - 2;
        }
        if (Player.getPos().getY() < 2) {
            leftY = 0;
        } else {
            leftY = Player.getPos().getY() - 2;
        }
        if (Player.getPos().getX() > WIDTH - 3) {
            rightX = WIDTH - 1;
        } else {
            rightX = Player.getPos().getX() + 2;
        }
        if (Player.getPos().getY() > HEIGHT - 3) {
            rightY = HEIGHT - 1;
        } else {
            rightY = Player.getPos().getY() + 2;
        }
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                view[i][j] = Tileset.NOTHING;
            }
        }
        for (int i = leftX; i <= rightX; i++) {
            for (int j = leftY; j <= rightY; j++) {
                view[i][j] = world[i][j];
            }
        }
        return view;
    }

    private long convertSeed(String seedString) {
        return Long.valueOf(seedString.toString());
    }

    private void saveGame(TETile[][] finalWorldFrame) {
        try {
            ObjectOutputStream out = new ObjectOutputStream(new FileOutputStream("savefile.txt"));
            out.writeObject(finalWorldFrame);
            out.writeObject(Player.getPos());
            out.writeObject(Player.appearanceChoice);
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private TETile[][] getSavedGame() {
        TETile[][] finalWorldFrame = null;
        try {
            ObjectInputStream in = new ObjectInputStream(new FileInputStream("savefile.txt"));
            finalWorldFrame = (TETile[][]) in.readObject();
            Player.setPos((Position) in.readObject());
            Player.changeAppearanceChoice((int) in.readObject());
            in.close();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }
        return finalWorldFrame;
    }

    private TETile[][] generateWorld(long seed) {
        TETile[][] world = new TETile[WIDTH][HEIGHT];
        initializeWorld(world);

        Random r = new Random(seed);

        List<Room> rooms = generateRooms(world, r, 10);
        generateHalls(world, r);
        generateConnectors(world, r, rooms);
        if (!rooms.isEmpty()) {
            carveDeadEnds(world);
        }
        carveExtraWalls(world);
        addDoorAndInitialPlayer(world, r);
        return world;
    }

    private void carveExtraWalls(TETile[][] world) {
        List<Position> solidWalls = new ArrayList<>();
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                Position p = new Position(i, j);
                if (p.isSolidWall(world, WIDTH, HEIGHT)) {
                    solidWalls.add(p);
                }
            }
        }

        for (Position p : solidWalls) {
            p.drawTile(world, Tileset.NOTHING);
        }
    }

    private void carveDeadEnds(TETile[][] world) {
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                Position p = new Position(i, j);
                if (p.isDeadEnd(world, WIDTH, HEIGHT)) {
                    p.carveDeadEnd(world, WIDTH, HEIGHT);
                }
            }
        }
    }

    private void addDoorAndInitialPlayer(TETile[][] world, Random r) {
        List<Position> edges = new ArrayList<>();
        for (int i = 0; i < WIDTH; i++) {
            for (int j = 0; j < HEIGHT; j++) {
                Position p = new Position(i, j);
                if (p.isEdge(world, WIDTH, HEIGHT)) {
                    edges.add(p);
                }
            }
        }
        int selector = RandomUtils.uniform(r, 0, edges.size());
        Position selected = edges.get(selector);
        selected.drawTile(world, Tileset.LOCKED_DOOR);
        selected.drawInitialPerson(world, WIDTH, HEIGHT, Player.appearanceChoice);
    }

    private void generateConnectors(TETile[][] world, Random r, List<Room> rooms) {
        for (Room room : rooms) {
            List<Connector> connectors = room.findConnectors(world, WIDTH, HEIGHT);
            if (connectors.size() == 0) {
                continue;
            }
            int numOfSelection = RandomUtils.uniform(r, 1, 4);
            for (int i = 0; i < numOfSelection; i++) {
                int selector = RandomUtils.uniform(r, 0, connectors.size());
                connectors.get(selector).connect(world, Tileset.FLOOR);
            }
            // int selector = RandomUtils.uniform(r, 0, connectors.size());
            // connectors.get(selector).connect(world, Tileset.FLOOR);
        }

        for (Room room : rooms) {
            room.drawRoom(world, Tileset.FLOOR);
        }
    }

    private List<Room> generateRooms(TETile[][] world, Random r, int roomNum) {
        Room.setRoomMaxNum(roomNum);
        List<Room> rooms = new ArrayList<>();
        for (int i = 0; i < Room.getRoomMaxNum(); ) {
            Room newRoom;
            do {
                Position p1 =
                        new Position(decideXOrY(r, 1, WIDTH - 3), decideXOrY(r, 1, HEIGHT - 3));
                Position p2 = new Position(decideXOrY(r, p1.getX() + 1, WIDTH - 1),
                        decideXOrY(r, p1.getY() + 1, HEIGHT - 1));
                newRoom = new Room(p1, p2);
            } while (!Room.isLegal(newRoom));
            if (!newRoom.isOverlapped(rooms)) {
                rooms.add(newRoom);
                i++;
                newRoom.drawRoom(world, Tileset.ROOMFLOOR);
            }
        }
        return rooms;
    }

    private void generateHalls(TETile[][] world, Random r) {
        // dfs
        Stack<Position> stack = new Stack<>();
        Position startPoint = decideStartPoint(r, world);
        startPoint.drawTile(world, Tileset.FLOOR);
        stack.push(startPoint);
        while (!stack.isEmpty()) {
            Position existed = stack.peek();
            Connector conn = nextConnector(r, existed, world);
            if (conn == null) {
                stack.pop();
                continue;
            }
            conn.getGoalPos().drawTile(world, Tileset.FLOOR);
            conn.connect(world, Tileset.FLOOR);
            stack.push(conn.getGoalPos());
        }
    }

    private void initializeWorld(TETile[][] world) {
        for (int x = 0; x < WIDTH; x++) {
            for (int y = 0; y < HEIGHT; y++) {
                world[x][y] = Tileset.WALL;
            }
        }

        for (int x = 1; x < WIDTH; x += 2) {
            for (int y = 1; y < HEIGHT; y += 2) {
                world[x][y] = Tileset.UNDEVFLOOR;
            }
        }
    }

    private Connector nextConnector(Random r, Position p, TETile[][] world) {
        List<Connector> possibleConnectors = new ArrayList<>();
        for (Direction d : Direction.values()) {
            Connector.addConnectableDirection(possibleConnectors, world, Tileset.UNDEVFLOOR, d, p,
                    WIDTH, HEIGHT);
        }
        if (possibleConnectors.isEmpty()) {
            return null;
        }
        int selector = RandomUtils.uniform(r, 0, possibleConnectors.size());
        return possibleConnectors.get(selector);
    }

    private Position decideStartPoint(Random r, TETile[][] world) {
        Position p = new Position();
        int selector = RandomUtils.uniform(r, 0, 4);
        switch (selector) {
            case 0:
                p.setX(1);
                do {
                    p.setY(decideXOrY(r, 1, HEIGHT - 1));
                } while (p.isTile(world, Tileset.ROOMFLOOR));
                break;
            case 1:
                p.setY(1);
                do {
                    p.setX(decideXOrY(r, 1, WIDTH - 1));
                } while (p.isTile(world, Tileset.ROOMFLOOR));
                break;
            case 2:
                p.setX(WIDTH - 2);
                do {
                    p.setY(decideXOrY(r, 1, HEIGHT - 1));
                } while (p.isTile(world, Tileset.ROOMFLOOR));
                break;
            default:
                p.setY(HEIGHT - 2);
                do {
                    p.setX(decideXOrY(r, 1, WIDTH - 1));
                } while (p.isTile(world, Tileset.ROOMFLOOR));
                break;
        }
        return p;
    }

    private int decideXOrY(Random r, int start, int end) {
        int x = RandomUtils.uniform(r, start, end);
        if (x % 2 == 0) {
            if (RandomUtils.bernoulli(r)) {
                x++;
            } else {
                x--;
            }
        }
        return x;
    }

    private void drawStartUI() {
        initializeCanvas();

        Font font = new Font("Monaco", Font.PLAIN, 60);
        StdDraw.setFont(font);
        StdDraw.text(WIDTH / 2, 3 * HEIGHT / 4, "CS61B: THE GAME");

        Font smallerFont = new Font("Monaco", Font.PLAIN, 18);
        StdDraw.setFont(smallerFont);
        StdDraw.text(1.8 * WIDTH / 2, HEIGHT, "(V) Turn On/Off ViewOn");

        Font smallFont = new Font("Monaco", Font.PLAIN, 30);
        StdDraw.setFont(smallFont);
        StdDraw.text(WIDTH / 2, HEIGHT / 4 + 2, "New Game (N)");
        StdDraw.text(WIDTH / 2, HEIGHT / 4, "Load Game (L)");
        StdDraw.text(WIDTH / 2, HEIGHT / 4 - 2, "Quit (Q)");
        StdDraw.text(WIDTH / 2, HEIGHT / 4 - 4, "Options (O)");
        StdDraw.text(WIDTH / 2, HEIGHT / 4 - 6, "Instruction (I)");

        StdDraw.show();
    }

    private void initializeCanvas() {
        StdDraw.setCanvasSize(WIDTH * 16, (HEIGHT + 1) * 16);
        StdDraw.setXscale(0, WIDTH);
        StdDraw.setYscale(0, HEIGHT + 1);
        StdDraw.clear(Color.BLACK);
        StdDraw.enableDoubleBuffering();
        StdDraw.setPenColor(Color.WHITE);
    }

}
