package byow.Core;

import byow.TileEngine.TETile;
import byow.TileEngine.Tileset;

public class Player {
    private static Position pos;
    public static int appearanceChoice = 1;
    public static Position getPos() {
        return pos;
    }

    public static void setPos(Position pos) {
        Player.pos = pos;
    }

    public static void walkLeft(TETile[][] world) {
        Position newPos = new Position(pos.getX() - 1, pos.getY());
        walk(world, newPos);
    }

    public static void walkRight(TETile[][] world) {
        Position newPos = new Position(pos.getX() + 1, pos.getY());
        walk(world, newPos);
    }

    public static void walkUp(TETile[][] world) {
        Position newPos = new Position(pos.getX(), pos.getY() + 1);
        walk(world, newPos);
    }

    public static void walkDown(TETile[][] world) {
        Position newPos = new Position(pos.getX(), pos.getY() - 1);
        walk(world, newPos);
    }

    private static void walk(TETile[][] world, Position newPos) {
        if (newPos.isTile(world, Tileset.FLOOR)) {
            pos.drawTile(world, Tileset.FLOOR);
            switch(appearanceChoice) {
                case 2:
                    newPos.drawTile(world, Tileset.AVATAR2);
                    break;
                case 3:
                    newPos.drawTile(world, Tileset.AVATAR3);
                    break;
                default:
                    newPos.drawTile(world, Tileset.AVATAR);
                    break;
            }
            pos = newPos;
        }
    }

    public static void changeAppearanceChoice (int choice) {
        appearanceChoice = choice;
    }

}
